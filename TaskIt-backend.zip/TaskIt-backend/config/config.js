// config/config.js
import dotenv from 'dotenv';
dotenv.config();

export default {
    development: {
        dialect: 'sqlite',
        storage: process.env.DATABASE_STORAGE || './db/taskit.sqlite',
        logging: console.log
    },
    test: {
        dialect: 'sqlite',
        storage: './db/taskit.sqlite',
        logging: false
    },
    production: {
        dialect: 'sqlite',
        storage: './db/taskit_prod.sqlite',
        logging: false
    },
    task: {
        statuses: ['pending', 'completed']
    }
};

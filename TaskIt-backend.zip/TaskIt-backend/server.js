import express from 'express';
import path from 'path';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import errorHandler from './middleware/errorHandler.js';
import authRoutes from './routes/authRoutes.js';
import taskRoutes from './routes/taskRoutes.js';
import { connectToDatabase } from './db/database.js';

import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(helmet()); // Add security headers
app.use(morgan('dev')); // Log HTTP requests in development mode
app.use(express.json()); // Parse incoming JSON requests

// API Routes
app.use('/api/auth', authRoutes); // Authentication routes
app.use('/api/tasks', taskRoutes); // Task management routes

// Serve React static files
app.use(express.static(path.join(__dirname, 'build')));

// Catch-all route to serve React's index.html
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

// Error handling middleware
app.use(errorHandler);

// Start the server and connect to the database
(async () => {
    await connectToDatabase(); // Ensure database connection is established
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
})();

export default app;

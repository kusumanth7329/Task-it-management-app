// db/database.js
import { Sequelize } from 'sequelize';

let config;
(async () => {
    config = await import('../config/config.js').then(module => module.default || module);
    console.log("Loaded config:", config); // Debugging line to see if config loads correctly
})();

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: config && config.development ? config.development.storage : './db/taskit.sqlite', // Fallback if config fails to load
    logging: process.env.NODE_ENV === 'development' ? console.log : false,
});

let isConnected = false;

const connectToDatabase = async () => {
    if (isConnected) return sequelize;

    try {
        await sequelize.authenticate();
        console.log('Connection to SQLite has been established successfully.');
        isConnected = true;
        return sequelize;
    } catch (error) {
        console.error('Unable to connect to the database:', error);
        throw error;
    }
};

const gracefulShutdown = async () => {
    if (isConnected) {
        try {
            await sequelize.close();
            console.log('Database connection has been closed gracefully.');
        } catch (error) {
            console.error('Error while closing the database connection:', error);
        }
    }
};

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);

export { sequelize as default, connectToDatabase };

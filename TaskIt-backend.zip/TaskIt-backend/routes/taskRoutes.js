// routes/taskRoutes.js
import express from 'express';
import { authenticate } from '../middleware/authMiddleware.js';
import {
    createTask,
    getAllTasks,
    getTaskById,
    updateTask,
    deleteTask
} from '../controllers/taskController.js';

const router = express.Router();

router.post('/', authenticate, createTask); // Protect route with authenticate middleware
router.get('/', authenticate, getAllTasks);
router.get('/:id', authenticate, getTaskById);
router.put('/:id', authenticate, updateTask);
router.delete('/:id', authenticate, deleteTask);

export default router;

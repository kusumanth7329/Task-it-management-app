import Joi from 'joi';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import dotenv from 'dotenv';
import User from '../db/models/users.js';

dotenv.config();

// Joi schemas for registration and login
const registrationSchema = Joi.object({
    username: Joi.string().min(3).required(),
    password: Joi.string()
        .min(8)
        .max(30)
        .pattern(new RegExp('^[a-zA-Z0-9@$!%*?&]{8,30}$'))
        .regex(/[A-Z]/)        // At least one uppercase letter
        .regex(/[a-z]/)        // At least one lowercase letter
        .regex(/[0-9]/)        // At least one digit
        .regex(/[@$!%*?&]/)    // At least one special character
        .required()
});

const loginSchema = Joi.object({
    username: Joi.string().required(),
    password: Joi.string().required()
});

// Register a new user with validation and unique username check
export const register = async (req, res) => {
    const { error } = registrationSchema.validate(req.body);
    if (error) {
        return res.status(400).json({ error: true, message: error.details[0].message });
    }

    const { username, password } = req.body;

    try {
        // Check if the username already exists in the database
        const existingUser = await User.findOne({ where: { username } });
        if (existingUser) {
            return res.status(400).json({ error: true, message: 'Username already exists' });
        }

        // Hash the password before saving it
        const hashedPassword = await bcrypt.hash(password, 10);

        // Save the new user to the database
        const user = await User.create({ username, password: hashedPassword });

        res.status(201).json({ message: 'User registered successfully!' });
    } catch (error) {
        res.status(500).json({ error: true, message: error.message });
    }
};

// Login a user and generate a JWT with validation
export const login = async (req, res) => {
    const { error } = loginSchema.validate(req.body);
    if (error) {
        return res.status(400).json({ error: true, message: error.details[0].message });
    }

    const { username, password } = req.body;

    try {
        // Find the user in the database
        const user = await User.findOne({ where: { username } });
        if (!user) {
            return res.status(401).json({ error: true, message: 'Invalid credentials' });
        }

        // Check if the password matches
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ error: true, message: 'Invalid credentials' });
        }

        // Generate a JWT token including user ID and username
        const token = jwt.sign({ id: user.id, username: user.username }, process.env.JWT_SECRET, {
            expiresIn: process.env.JWT_EXPIRES_IN || '1h'
        });

        res.status(200).json({ message: 'Login successful', token });
    } catch (error) {
        res.status(500).json({ error: true, message: error.message });
    }
};

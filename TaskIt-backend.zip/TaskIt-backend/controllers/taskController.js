// controllers/taskController.js
import Joi from 'joi';
import Task from '../db/models/Task.js';

// Define a Joi schema for task validation
const taskSchema = Joi.object({
    title: Joi.string().min(3).required(),
    description: Joi.string().optional(),
    status: Joi.string().valid('pending', 'completed').optional(),
    priority: Joi.string().valid('low', 'medium', 'high').optional(),
    dueDate: Joi.date().optional()
});

// Create a new task with validation
export const createTask = async (req, res) => {
    const { error } = taskSchema.validate(req.body);
    if (error) {
        return res.status(400).json({ error: true, message: error.details[0].message });
    }

    try {
        const { title, description, status, priority, dueDate } = req.body;
        const task = await Task.create({ title, description, status, priority, dueDate, userId: req.user.id });
        res.status(201).json(task);
    } catch (error) {
        res.status(500).json({ error: true, message: error.message });
    }
};

// Get all tasks with pagination, filtering, and sorting by priority or due date
export const getAllTasks = async (req, res) => {
    try {
        const { page = 1, limit = 10, status, sortBy } = req.query;

        const offset = (page - 1) * limit;
        const whereClause = { userId: req.user.id };
        if (status) whereClause.status = status;

        const order = sortBy === 'priority' || sortBy === 'dueDate' ? [[sortBy, 'ASC']] : [['createdAt', 'DESC']];

        const tasks = await Task.findAndCountAll({
            where: whereClause,
            limit: parseInt(limit),
            offset: parseInt(offset),
            order
        });

        res.status(200).json({
            data: tasks.rows,
            totalItems: tasks.count,
            totalPages: Math.ceil(tasks.count / limit),
            currentPage: parseInt(page)
        });
    } catch (error) {
        res.status(500).json({ error: true, message: error.message });
    }
};

// Get a task by ID
export const getTaskById = async (req, res) => {
    try {
        const task = await Task.findOne({ where: { id: req.params.id, userId: req.user.id } });
        if (!task) return res.status(404).json({ error: true, message: 'Task not found' });
        res.status(200).json(task);
    } catch (error) {
        res.status(500).json({ error: true, message: error.message });
    }
};

// Update a task with validation
export const updateTask = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, status, priority, dueDate } = req.body;

        // Find the task and update only the allowed fields
        const task = await Task.findOne({ where: { id } });
        if (!task) {
            return res.status(404).json({ message: "Task not found" });
        }

        // Update task fields
        await task.update({ title, description, status, priority, dueDate });
        
        res.json(task);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to update task" });
    }
};

// Delete a task by ID
export const deleteTask = async (req, res) => {
    try {
        const task = await Task.findOne({ where: { id: req.params.id, userId: req.user.id } });
        if (!task) return res.status(404).json({ error: true, message: 'Task not found' });

        await task.destroy();
        res.status(200).json({ message: 'Task has been successfully deleted' });
    } catch (error) {
        res.status(500).json({ error: true, message: error.message });
    }
};

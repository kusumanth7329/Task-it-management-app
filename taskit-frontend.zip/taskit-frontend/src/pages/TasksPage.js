import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import '../styles/TasksPage.css';
import { useAuth } from '../context/AuthContext';

const TasksPage = () => {
    const [tasks, setTasks] = useState([]);
    const [newTask, setNewTask] = useState({
        title: '',
        description: '',
        status: 'pending',
        priority: 'medium',
        dueDate: ''
    });
    const [editTaskId, setEditTaskId] = useState(null);
    const [editFormData, setEditFormData] = useState({
        title: '',
        description: '',
        status: 'pending',
        priority: 'medium',
        dueDate: ''
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const { isAuthenticated } = useAuth();

    useEffect(() => {
        if (!isAuthenticated) {
            navigate('/login');
            return;
        }
        fetchTasks();
    }, [isAuthenticated, navigate]);

    const fetchTasks = async () => {
        setLoading(true);
        try {
            const response = await api.get('/tasks', {
                headers: { Authorization: `Bearer ${sessionStorage.getItem('token')}` }
            });
            const data = Array.isArray(response.data) ? response.data : [];
            setTasks(data);
            setLoading(false);
        } catch (err) {
            console.error('Error fetching tasks:', err);
            setError('Failed to fetch tasks. ' + (err.response?.data?.message || err.message));
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewTask(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleEditInputChange = (e) => {
        const { name, value } = e.target;
        setEditFormData(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleCreateTask = async (e) => {
        e.preventDefault();
        setError('');
        try {
            const response = await api.post('/tasks', newTask, {
                headers: { Authorization: `Bearer ${sessionStorage.getItem('token')}` }
            });
            setTasks([...tasks, response.data]);
            setNewTask({ title: '', description: '', status: 'pending', priority: 'medium', dueDate: '' });
        } catch (err) {
            setError('Failed to create task. ' + (err.response?.data?.message || err.message));
        }
    };

    const handleUpdateTask = (id) => {
        const task = tasks.find(task => task.id === id);
        setEditTaskId(id);
        setEditFormData({ ...task }); // Ensure a clean copy of the task is used for editing
    };

    const handleSaveTask = async (id) => {
        setError('');
        try {
            // Ensure no server-protected fields are sent
            const { id: _, userId, updatedAt, ...updateData } = { ...editFormData };

            const response = await api.put(`/tasks/${id}`, updateData, {
                headers: { Authorization: `Bearer ${sessionStorage.getItem('token')}` }
            });

            const updatedTasks = tasks.map(task => task.id === id ? { ...task, ...response.data } : task);
            setTasks(updatedTasks);

            // Clear edit state after saving
            setEditTaskId(null);
            setEditFormData({ title: '', description: '', status: 'pending', priority: 'medium', dueDate: '' });
        } catch (err) {
            console.error('Failed to update task:', err);
            setError('Failed to update task. ' + (err.response?.data?.message || err.message));
        }
    };

    const handleDeleteTask = async (id) => {
        setError('');
        try {
            await api.delete(`/tasks/${id}`, {
                headers: { Authorization: `Bearer ${sessionStorage.getItem('token')}` }
            });
            setTasks(tasks.filter(t => t.id !== id));
        } catch (err) {
            setError('Failed to delete task. ' + (err.response?.data?.message || err.message));
        }
    };

    return (
        <div className="tasks-page">
            <div className="tasks-container">
                <div className="tasks-form">
                    <h2>Task Manager</h2>
                    <form onSubmit={handleCreateTask}>
                        <input
                            type="text"
                            placeholder="Title"
                            name="title"
                            value={newTask.title}
                            onChange={handleInputChange}
                            required
                        />
                        <textarea
                            placeholder="Description"
                            name="description"
                            value={newTask.description}
                            onChange={handleInputChange}
                        ></textarea>
                        <select name="status" value={newTask.status} onChange={handleInputChange}>
                            <option value="pending">Pending</option>
                            <option value="completed">Completed</option>
                        </select>
                        <select name="priority" value={newTask.priority} onChange={handleInputChange}>
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                        </select>
                        <input
                            type="date"
                            name="dueDate"
                            value={newTask.dueDate}
                            onChange={handleInputChange}
                        />
                        <button type="submit">Add Task</button>
                    </form>
                </div>
                <div className="tasks-list">
                    {tasks.length > 0 ? (
                        <div className="task-list">
                            {tasks.map(task => (
                                <li key={task.id}>
                                    {editTaskId === task.id ? (
                                        <div className="edit-task-form">
                                            <input type="text" name="title" value={editFormData.title} onChange={handleEditInputChange} />
                                            <textarea name="description" value={editFormData.description} onChange={handleEditInputChange} />
                                            <select name="status" value={editFormData.status} onChange={handleEditInputChange}>
                                                <option value="pending">Pending</option>
                                                <option value="completed">Completed</option>
                                            </select>
                                            <select name="priority" value={editFormData.priority} onChange={handleEditInputChange}>
                                                <option value="low">Low</option>
                                                <option value="medium">Medium</option>
                                                <option value="high">High</option>
                                            </select>
                                            <input type="date" name="dueDate" value={editFormData.dueDate ? editFormData.dueDate.split('T')[0] : ''} onChange={handleEditInputChange} />
                                            <button onClick={() => handleSaveTask(task.id)}>Save</button>
                                            <button onClick={() => setEditTaskId(null)}>Cancel</button>
                                        </div>
                                    ) : (
                                        <div>
                                            <h3>{task.title}</h3>
                                            <p>{task.description}</p>
                                            <p>Status: {task.status}</p>
                                            <p>Priority: {task.priority}</p>
                                            <p>Due Date: {task.dueDate ? new Date(task.dueDate).toLocaleDateString() : 'None'}</p>
                                            <button onClick={() => handleUpdateTask(task.id)}>Edit</button>
                                            <button onClick={() => handleDeleteTask(task.id)}>Delete</button>
                                        </div>
                                    )}
                                </li>
                            ))}
                        </div>
                    ) : (
                        <div className="empty-state">
                            <img src={require("../assets/empty.png")} alt="All caught up!" />
                            <h3>You're all caught up! 🎉</h3>
                        </div>
                    )}
                </div>
            </div>
            {error && <p className="error">{error}</p>}
        </div>
    );
};

export default TasksPage;

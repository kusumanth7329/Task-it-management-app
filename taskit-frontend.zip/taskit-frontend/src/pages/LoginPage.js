// src/pages/LoginPage.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import '../styles/LoginPage.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useAuth } from '../context/AuthContext'; // Make sure to import useAuth

const LoginPage = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();
    const { setIsAuthenticated } = useAuth(); // Use the Auth context

    const handleLogin = async (e) => {
        e.preventDefault();
        setError(''); // Clear any previous error

        try {
            // Make the login API request
            const response = await api.post('/auth/login', { username, password });
            console.log("API Response:", response); // Debugging line

            // Check if the token exists and log it
            const token = response.data.token;
            console.log("Token received:", token); // Debugging line

            if (token) {
                // Store the token in session storage
                sessionStorage.setItem('token', token);
                console.log("Token stored in sessionStorage."); // Debugging line

                // Update authentication status
                setIsAuthenticated(true);

                // Redirect to the tasks page after successful login
                navigate('/tasks');
                console.log("Navigation to tasks page triggered."); // Debugging line
            } else {
                throw new Error('No token received from the server.');
            }
        } catch (err) {
            // Handle errors, such as invalid credentials
            console.error("Login error:", err);
            setError(err.response?.data?.message || 'Login failed. Please try again.');
        }
    };

    return (
        <div className="login-page d-flex align-items-center justify-content-center">
            <div className="card login-card shadow">
                <div className="card-body">
                    <h2 className="text-center mb-4">Welcome Back</h2>
                    <form onSubmit={handleLogin}>
                        <div className="form-group mb-3">
                            <label htmlFor="username">Username</label>
                            <input
                                type="text"
                                className="form-control"
                                id="username"
                                placeholder="Enter your username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                required
                            />
                        </div>
                        <div className="form-group mb-3">
                            <label htmlFor="password">Password</label>
                            <input
                                type="password"
                                className="form-control"
                                id="password"
                                placeholder="Enter your password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                            />
                        </div>
                        <button type="submit" className="btn btn-primary w-100">Login</button>
                    </form>
                    {error && <p className="text-danger text-center mt-3">{error}</p>}
                    <p className="text-center mt-3">
                        Don't have an account? <a href="/register">Register here</a>
                    </p>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;

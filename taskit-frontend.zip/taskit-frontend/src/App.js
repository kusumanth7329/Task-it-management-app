// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import TasksPage from './pages/TasksPage';
import './App.css'; 

const Header = () => (
    <header className="app-header">
        <a href="/" className="logo-link">
            <img src={require('./assets/logo.png')} alt="TaskIt Logo" className="app-logo" />
            <span className="logo-text">TaskIt</span>
        </a>
    </header>
);

const Footer = () => (
    <footer className="app-footer">
        <p>
            Designed by Kusumanth Reddy Gali |
            <a href="mailto:Gali.k@northeastern.edu"> Gali.k@northeastern.edu</a> |
            <a href="https://www.linkedin.com/in/kusumanth-gali-41736617a/" target="_blank" rel="noopener noreferrer">
                LinkedIn
            </a>
        </p>
    </footer>
);

const AuthRoutes = () => {
    const { isAuthenticated } = useAuth();

    return (
        <Routes>
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="/login" element={isAuthenticated ? <Navigate to="/tasks" replace /> : <LoginPage />} />
            <Route path="/register" element={isAuthenticated ? <Navigate to="/tasks" replace /> : <RegisterPage />} />
            <Route path="/tasks" element={isAuthenticated ? <TasksPage /> : <Navigate to="/login" replace />} />
            <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
    );
};

const App = () => {
    return (
        <Router>
            <AuthProvider>
                <div className="app-container">
                    <Header />
                    <main className="main-content">
                        <AuthRoutes />
                    </main>
                    <Footer />
                </div>
            </AuthProvider>
        </Router>
    );
};

export default App;
